package com.lti.dao;

import java.util.List;

import com.lti.model.Admin;
import com.lti.model.InsuranceForClaim;
import com.lti.model.SellRequest;
import com.lti.model.User;

public interface AdminDao {
	
	public List<User> findRegistrationPendingRequest();
	public int rejectUser( int userId) ;
	public int updateLoginStatus(int userId);
	public Admin readAdminLogin(String username,String password);
	public User readUserDetails(int userId);
	public List<SellRequest> findPendingSellRequest();
	public int updateSellRequestStatus(int requestId);
	public int rejectSellRequest(int requestId);
	public List<InsuranceForClaim> readAllClaimedinsurance();
	public boolean approveClaimedInsurance(int policyNo);
	public boolean cropSold(int bidId, int sellRequestId);
	public List<SellRequest> fetchAllCurrentBiddingForAdmin();
	public int acceptBidByAdmin(int sellRequestId);

}
