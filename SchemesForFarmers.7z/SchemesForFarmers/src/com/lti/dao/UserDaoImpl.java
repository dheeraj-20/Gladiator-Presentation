package com.lti.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.model.User;

@Repository
public class UserDaoImpl implements UserDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Autowired
	User user;
	
	public int createUser(User user) {
		entityManager.merge(user);
		return 1;
	}

	public User readUserLogin(String username, String password) {
		
	
		String jpql = "Select u from User u where u.email=:username and u.password=:password";
		TypedQuery<User> tquery = entityManager.createQuery(jpql, User.class);
		tquery.setParameter("username", username);
		tquery.setParameter("password", password);
		if (tquery.getResultList().size() != 0) {
			user = tquery.getSingleResult();
			return user;
		} else 
			return null;

	}
	public User readUserDetails(String username) {
	
		String jpql = "Select u from User u where u.email=:username";
		TypedQuery<User> tquery = entityManager.createQuery(jpql, User.class);
		tquery.setParameter("username", username);
		
		if (tquery.getResultList().size() != 0) {
			user = tquery.getSingleResult();
		
			return user;
		} else 
			return null;
	}

}
