package com.lti.dao;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.model.BidRequest;
import com.lti.model.SellRequest;
import com.lti.model.User;
import com.lti.service.AdminService;
import com.lti.service.FarmerService;
import com.lti.service.UserService;

@Repository
public class TraderDaoImpl implements TraderDao {

	LocalDate localDate = LocalDate.now();

	@PersistenceContext
	private EntityManager entityManager;
	
	@Autowired
	BidRequest bidRequest;
	
	@Autowired
	User user;
	
	@Autowired
	SellRequest sellRequest;
	
	@Autowired
	AdminService aService;
	
	@Autowired
	FarmerService fService;
	
	

	public int addBidRequest(BidRequest bidRequest) {
		entityManager.persist(bidRequest);
		return 1;
	}

	public List<SellRequest> readSellRequest() {
		String jpql = "select s From SellRequest s where s.status ='APPROVED' ";
		TypedQuery<SellRequest> tquery = entityManager.createQuery(jpql, SellRequest.class);
		List<SellRequest> list = tquery.getResultList();
	
		if (list.size() != 0) {
			return list;
		} else {
			return null;
		}
	}
	
	public int updateCurrentBidAmount(int requestId,float bidAmount,int userId){
		
		bidRequest.setBidAmount(bidAmount);
		user = aService.getUserDetails(userId);
		sellRequest = fService.getSellRequestDetails(requestId);
		bidRequest.setUser(user);
		bidRequest.setSellRequest(sellRequest);
		bidRequest.setBidDate(DateTimeFormatter.ofPattern( "yyyy-MM-dd").format(localDate));
		
		entityManager.merge(bidRequest);
		
		String jpql = "UPDATE SellRequest s SET s.currentBid =:bidAmount WHERE s.requestId =:reqId";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("bidAmount", bidAmount);
		query.setParameter("reqId", requestId);
		int update = query.executeUpdate();
		
		
		return update;
	}

}
