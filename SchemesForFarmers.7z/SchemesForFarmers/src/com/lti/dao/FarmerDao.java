package com.lti.dao;

import java.util.List;

import com.lti.model.AppliedInsurance;
import com.lti.model.Crop;
import com.lti.model.InsuranceForClaim;
import com.lti.model.Land;
import com.lti.model.SellRequest;
import com.lti.model.User;

public interface FarmerDao {

		public List<Crop> readAllCrops();

		public Crop readCropById(int cropId);

		public int insertSellRequest(SellRequest sellRequest);

		public User readUserById(int userId);

		public int insertLandDetails(Land land);

		public List<Land> readAllLands(int userId);
		
		public SellRequest readSellRequestById(int sellRequest);

		public boolean insertInsuranceRequest(AppliedInsurance appliedInsurance);

		public List<AppliedInsurance> readAllAppliedInsuranceDetails(int userId);

		public AppliedInsurance fetchAppliedInsuranceById(int policyNo);

		public boolean insertInsuranceClaimRequest(InsuranceForClaim insuranceForClaim);

		public List<SellRequest> readAllCurrentBidding(int userId);
		
		public boolean accceptBid( int sellRequestId);
		
		public List<SellRequest> soldCrop(int userId);

	
}
