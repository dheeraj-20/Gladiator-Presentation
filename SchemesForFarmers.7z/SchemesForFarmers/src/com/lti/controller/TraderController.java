package com.lti.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.lti.service.TraderService;

@Controller
public class TraderController {


	@Autowired
	private TraderService service;

	@RequestMapping(path = "welcomeTraderPage", method = RequestMethod.GET)
	public String welcomeTrade(Model model) {
		return "welcomeTrader";
	}
	
	@RequestMapping(path = "updateAmount", method = RequestMethod.GET)
	public String changeCurrentBidAmount(@RequestParam(name="requestId") int requestId,@RequestParam(name="changedAmount") long bidAmount,
			@RequestParam(name="userId") int userId ) {
		boolean result = service.changeCurrentBidAmount(requestId, bidAmount, userId);
		if(result)
			return "welcomeTrader";
		else
			return "welcomeTrader";

	}
	
	@ExceptionHandler({Exception.class})
	public String handleException(){
		return "errorPage";
	}
	
}
