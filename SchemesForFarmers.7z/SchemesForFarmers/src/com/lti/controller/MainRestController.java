package com.lti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.model.Crop;
import com.lti.model.SellRequest;
import com.lti.service.FarmerService;
import com.lti.service.TraderService;

@RestController
public class MainRestController {
	
	@Autowired
	private FarmerService service;
	
	@Autowired
	private TraderService tservice;

	
	
	@RequestMapping(value = "getAllCrops", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Crop> cropType() {
		List<Crop> crops = service.fetchCropDetails();
		return crops;
    }
	
	@RequestMapping(value = "getAllSellRequests", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<SellRequest> getRequests(){
		List<SellRequest> sellRequests = tservice.getSellRequest();
		return sellRequests;
	}
	
	@ExceptionHandler({Exception.class})
	public String handleException(){
		return "errorPage";
	}
	
}
