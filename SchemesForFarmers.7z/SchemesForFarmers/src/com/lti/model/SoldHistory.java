package com.lti.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
@Scope(value = "prototype")
@Component
@Table(name = "tSoldHistory")
@SequenceGenerator(name = "sold_crop_history", sequenceName = "tSoldHistory_seq")
public class SoldHistory implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "SOLD_HISTORY_ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sold_crop_history")
	private int soldCropHistoryId;

	@Column(name = "SOLD_AMOUNT")
	private long soldAmount;

	@Column(name = "SOLD_CROP_DATE")
	private String soldDate;

	@OneToOne
	@JoinColumn(name = "REQUEST_ID")
	private SellRequest requestId;

	public SoldHistory() {

	}

	public SoldHistory(int soldCropHistoryId, long soldAmount, String soldDate) {
		super();
		this.soldCropHistoryId = soldCropHistoryId;
		this.soldAmount = soldAmount;
		this.soldDate = soldDate;
	}

	public int getSoldCropHistoryId() {
		return soldCropHistoryId;
	}

	public void setSoldCropHistoryId(int soldCropHistoryId) {
		this.soldCropHistoryId = soldCropHistoryId;
	}

	public long getSoldAmount() {
		return soldAmount;
	}

	public void setSoldAmount(long soldAmount) {
		this.soldAmount = soldAmount;
	}

	public SellRequest getRequestId() {
		return requestId;
	}

	public void setRequestId(SellRequest requestId) {
		this.requestId = requestId;
	}

	public String getSoldDate() {
		return soldDate;
	}

	public void setSoldDate(String soldDate) {
		this.soldDate = soldDate;
	}
}
