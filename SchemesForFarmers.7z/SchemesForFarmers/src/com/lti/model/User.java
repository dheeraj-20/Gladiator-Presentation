package com.lti.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
@Scope(value = "prototype")
@Component
@Table(name = "tUsers")
@SequenceGenerator(name = "seq", sequenceName = "tUsers_seq")
public class User implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
	@Column(name = "user_id")
	private int userId;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "middle_name")
	private String middleName;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "phone_number")
	private String phoneNumber;

	private String email;
	private String landmark;
	private String locality;
	private long pincode;
	private String district;
	private String state;

	@Column(name = "account_number")
	private String accountNumber;

	@Column(name = "ifsc_code")
	private String ifscCode;

	@Column(name = "aadhar_card")
	private String aadharCard;

	@Column(name = "pan_card")
	private String panCard;

	private String certificate;
	private String password;
	private String role;
	private String status;

	/*@OneToMany(mappedBy = "user")
	private Set<Land> lands = new HashSet<Land>();*/

	/*@OneToMany(mappedBy = "user")
	private Set<AppliedInsurance> insurances = new HashSet<AppliedInsurance>();*/

	public User() {

	}

	public User(int userId, String firstName, String middleName, String lastName, String phoneNumber, String email,
			String landmark, String locality, long pincode, String district, String state, String account_number,
			String ifscCode, String aadharCard, String panCard, String certificate, String password, String role,
			String status) {
		super();
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.landmark = landmark;
		this.locality = locality;
		this.pincode = pincode;
		this.district = district;
		this.state = state;
		this.accountNumber = account_number;
		this.ifscCode = ifscCode;
		this.aadharCard = aadharCard;
		this.panCard = panCard;
		this.certificate = certificate;
		this.password = password;
		this.role = role;
		this.status = status;
	}

	/*
	 * @ManyToOne(cascade = CascadeType.ALL) private List<Land> lands = new
	 * ArrayList<Land>();
	 */

	public int getUserId() {
		return userId;
	}

	public void setUser_id(int userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public long getPincode() {
		return pincode;
	}

	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getAadharCard() {
		return aadharCard;
	}

	public void setAadharCard(String aadharCard) {
		this.aadharCard = aadharCard;
	}

	public String getPanCard() {
		return panCard;
	}

	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}

	public String getCertificate() {
		return certificate;
	}

	public void setCertificate(String certificate) {
		this.certificate = certificate;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	/*public Set<AppliedInsurance> getInsurances() {
		return insurances;
	}

	public void setInsurances(Set<AppliedInsurance> insurances) {
		this.insurances = insurances;
	}

	public Set<Land> getLands() {
		return lands;
	}

	public void setLands(Set<Land> lands) {
		this.lands = lands;
	}*/
}
