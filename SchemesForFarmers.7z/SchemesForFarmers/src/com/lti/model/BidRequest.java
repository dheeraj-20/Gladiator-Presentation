package com.lti.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
@Scope(value = "prototype")
@Component
@Table(name = "tBidRequests")
@SequenceGenerator(name = "bid_seq", sequenceName = "tBidRequests_seq")
public class BidRequest implements Serializable{

	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bid_seq")
	@Column(name="bid_request_id")
	private int bidId;
	
	@Column(name="bid_amount")
	private float bidAmount;
	
	@Column(name="bid_date")
	private String bidDate;
	
	

	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;

	@ManyToOne
	@JoinColumn(name = "request_id")
	private SellRequest sellRequest;

	public BidRequest() {

	}

	public BidRequest(int bidId, long bidAmount, String bidDate, User user, SellRequest sellRequest) {
		super();
		this.bidId = bidId;
		this.bidAmount = bidAmount;
		this.bidDate = bidDate;
		this.user = user;
		this.sellRequest = sellRequest;
	}

	public int getBidId() {
		return bidId;
	}

	public void setBidId(int bidId) {
		this.bidId = bidId;
	}

	

	public float getBidAmount() {
		return bidAmount;
	}

	public void setBidAmount(float bidAmount) {
		this.bidAmount = bidAmount;
	}

	public String getBidDate() {
		return bidDate;
	}

	public void setBidDate(String bidDate) {
		this.bidDate = bidDate;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public SellRequest getSellRequest() {
		return sellRequest;
	}

	public void setSellRequest(SellRequest sellRequest) {
		this.sellRequest = sellRequest;
	}

	@Override
	public String toString() {
		return "BidRequest [bidId=" + bidId + ", bidAmount=" + bidAmount + ", bidDate=" + bidDate + ", user=" + user
				+ ", sellRequest=" + sellRequest + "]";
	}

}
