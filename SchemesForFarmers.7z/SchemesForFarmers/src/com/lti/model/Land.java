package com.lti.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Component
@Table(name = "tLands")
@SequenceGenerator(name = "sell_land", sequenceName = "tLands_seq")
public class Land implements Serializable {

	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "land_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sell_land")
	private int landId;

	@Column(name = "land_area")
	private float landArea;

	@Column(name = "land_address")
	private String landAddress;

	@Column(name = "land_pincode")
	private long landPincode;

	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;

	public Land() {

	}

	public Land(int landId, float landArea, String landAddress, long landPincode) {
		super();
		this.landId = landId;
		this.landArea = landArea;
		this.landAddress = landAddress;
		this.landPincode = landPincode;

	}

	public int getLandId() {
		return landId;
	}

	public void setLandId(int landId) {
		this.landId = landId;
	}

	public float getLandArea() {
		return landArea;
	}

	public void setLandArea(float landArea) {
		this.landArea = landArea;
	}

	public String getLandAddress() {
		return landAddress;
	}

	public void setLandAddress(String landAddress) {
		this.landAddress = landAddress;
	}

	public long getLandPincode() {
		return landPincode;
	}

	public void setLandPincode(long landPincode) {
		this.landPincode = landPincode;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Land [landId=" + landId + ", landArea=" + landArea + ", landAddress=" + landAddress + ", landPincode="
				+ landPincode + ", user=" + user + "]";
	}

}
