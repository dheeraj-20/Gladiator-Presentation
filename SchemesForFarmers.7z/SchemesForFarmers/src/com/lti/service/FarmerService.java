package com.lti.service;

import java.util.List;

import com.lti.model.AppliedInsurance;
import com.lti.model.Crop;
import com.lti.model.InsuranceForClaim;
import com.lti.model.Land;
import com.lti.model.SellRequest;
import com.lti.model.User;

public interface FarmerService {

		public List<Crop> fetchCropDetails();

		public Crop getCropById(int cropId);

		public boolean addSellRequest(SellRequest sellRequest);

		public User getUserById(int userId);

		public boolean addLandDetails(Land land);

		public List<Land> fetchAllLands(int userId);
		
		public SellRequest getSellRequestDetails(int sellRequestId);

		public int addInsuranceRequest(AppliedInsurance appliedInsurance);

		public List<AppliedInsurance> fetchAllAplliedInsurance(int userId);

		public AppliedInsurance getAppliedInsuranceById(int policyNo);

		public int addInsuranceClaimRequest(InsuranceForClaim insuranceForClaim);

		public List<SellRequest> fetchAllCurrentBidding(int userId);
		
		public int acceptBid(int sellRequestId);
		
		public List<SellRequest> soldCrop(int userId);

}
