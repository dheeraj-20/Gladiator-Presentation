package com.lti.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dao.UserDao;
import com.lti.model.User;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao dao;
	
	@Transactional
	public boolean registerUser(User user) {
		
		int result = dao.createUser(user);
		if(result==1)
			return true;
		else
			return false;
	}

	@Transactional
	public User checkLogin(String username, String password) {
		return dao.readUserLogin(username, password);
		
	}
	
	public User getUser(String username) {
		return dao.readUserDetails(username);
		
	}
	

}
