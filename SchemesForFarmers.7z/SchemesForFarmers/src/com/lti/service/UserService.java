package com.lti.service;

import com.lti.model.User;

public interface UserService {
	
	public boolean registerUser(User user);
	
	public User checkLogin(String username,String password);
	
	public User getUser(String username);
}
